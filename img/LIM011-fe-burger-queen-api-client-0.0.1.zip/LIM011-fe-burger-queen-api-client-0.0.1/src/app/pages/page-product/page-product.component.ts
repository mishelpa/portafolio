import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-product',
  templateUrl: './page-product.component.html',
  styleUrls: ['./page-product.component.scss']
})
export class PageProductComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }

}
