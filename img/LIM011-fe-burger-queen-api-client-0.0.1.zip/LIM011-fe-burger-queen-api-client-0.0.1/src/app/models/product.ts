export class Product {
    id: string;
    name: string;
    price: number;
    image: string;
    type: string;
    dateEntry: Date;
}
