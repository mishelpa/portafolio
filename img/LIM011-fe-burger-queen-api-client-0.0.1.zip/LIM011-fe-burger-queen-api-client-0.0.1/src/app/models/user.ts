export class User {
    email: string;
    password: string;
    roles: { admin: boolean };
}
